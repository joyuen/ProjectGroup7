//
//  File.swift
//  test
//
//  Created by jdyuen on 3/2/17.
//  Copyright © 2017 cmpt276. All rights reserved.
//

import UIKit

class TitleController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    }
    
}
